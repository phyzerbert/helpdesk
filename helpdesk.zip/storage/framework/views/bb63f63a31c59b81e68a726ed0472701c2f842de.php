<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-database"></i>&nbsp;Knowledge Base</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="#">Knowledge Base</a></li>
        </ul>
    </div>
    <div class="">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="tile">
                    <div class="tile-header">                     
                        <h3>Create Article</h3>                                 
                    </div>
                    <div class="tile-body">                        
                        <form method="post" action="<?php echo e(route('kdb.save')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12 mb-4">
                                    <label>Knowledge Base Number</label>
                                    <input class="form-control" type="text" name="kb_number" id="kb_number" value="<?php echo e($kb_number); ?>" readonly>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-md-12 mb-4">
                                    <label>Category</label>
                                    <select name="category" id="category" class="form-control">
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-md-12 mb-4">
                                    <label>Problem</label>
                                    <input class="form-control" type="text" name="problem" id="problem" placeholder="Type minimum 25 characters" />
                                </div>
                                <div class="clearfix"></div>
                                <div class="col-md-12 mb-4">
                                    <label>Solution</label>
                                    <textarea class="form-control" name="solution" id="solution" rows="5" placeholder="Type Solution..."></textarea>
                                </div>
                            </div>
                            <div class="row mb-10">
                                <div class="col-md-12">
                                    <button class="btn btn-primary float-right" id="profile-submit" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i> Save</button>
                                </div>
                            </div>
                        </form>
                    </div>                   
                </div>
            </div>            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\helpdesk\helpdesk\resources\views/kdb/create.blade.php */ ?>